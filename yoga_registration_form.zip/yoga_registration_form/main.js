const menu = document.getElementById("menu_btn");
const navLinks = document.getElementById("nav_links");
const menuBtnIcon = menu.querySelector("span");

menuBtnIcon.addEventListener("click", () => {
    navLinks.classList.toggle("open");

    const isOpen = navLinks.classList.contains("open");
    menuBtnIcon.setAttribute = isOpen ? "close" : "menu";
});
navLinks.addEventListener("click",()=>
{
    navLinks.classList.remove("open");
    menuBtnIcon.setAttribute("class","ri-menu-4-line");


});